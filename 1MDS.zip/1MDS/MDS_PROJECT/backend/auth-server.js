import express from "express";
import cors from "cors";

const app = express();
app.use(express.json());
app.use(cors());

// jednoduché testovacie heslá
const PASSWORD = "1"
    /*"2": "2",
    "3": "3",
    "4": "4",
    "5": "5",
    "6": "6",
    "janko": "1234",
    "admin": "admin",
    "user": "password"*/

// POST /authenticate
app.post("/authenticate", (req, res) => {
    const { username, password } = req.body;

    if (!password) {
        return res.status(400).json({ authenticated: false, error: "Missing credentials" });
    }

    if (PASSWORD === password) {
        return res.json({ authenticated: true });
    }

    return res.status(401).json({ authenticated: false });
});

app.listen(3000, () => {
    console.log("✔️ Auth server running on http://localhost:3000");
});
