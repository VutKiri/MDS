// live-server.js – jednoduchá HLS pipeline (1 kvalita) z udp://127.0.0.1:10000

import express from "express";
import cors from "cors";
import path from "path";
import fs from "fs";
import { fileURLToPath } from "url";
import { spawn } from "child_process";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(cors());
app.use(express.json());

// ==============================
// CESTY
// ==============================
const HLS_DIR = path.join(__dirname, "../hls");
const VIEWER_DIR = path.join(__dirname, "../viewer");
const STATUS_FILE = path.join(__dirname, "../hls/status.json");

/**
 * Uloží jméno prezentujúceho a (voliteľne) stav aktivity do status.json.
 * @param {string} presenterName Jméno prezentujúceho
 */
function savePresenterStatus(presenterName) {
    let currentStatus = { active: true, presenter: null, presenters: [] }; // Nastavíme active na true

    if (fs.existsSync(STATUS_FILE)) {
        try {
            const data = fs.readFileSync(STATUS_FILE, "utf8");
            currentStatus = JSON.parse(data);
        } catch (e) {
            console.error("Chyba pri čítaní status.json:", e);
        }
    }
    
    // Uistíme sa, že je stream aktívny a aktualizujeme jméno
    currentStatus.active = true;
    currentStatus.presenter = presenterName;
    currentStatus.presenters = [presenterName];
    
    // Zápis aktualizovaného stavu zpět do souboru
    try {
        fs.writeFileSync(STATUS_FILE, JSON.stringify(currentStatus, null, 2), "utf8");
        console.log(`✅ Uložené nové jméno prezentujúceho: ${presenterName}`);
        return true;
    } catch (e) {
        console.error("Chyba pri zápise do status.json:", e);
        return false;
    }
}


/**
 * Vymaže jméno prezentujícího a nastaví active: false.
 */
function clearPresenterStatus() {
    let currentStatus = { active: false, presenter: null, presenters: [] };

    if (fs.existsSync(STATUS_FILE)) {
        try {
            const data = fs.readFileSync(STATUS_FILE, "utf8");
            currentStatus = JSON.parse(data);
        } catch (e) {
            console.error("Chyba pri čítaní status.json:", e);
        }
    }

    // Reset jména a stavu
    currentStatus.presenter = null;
    currentStatus.presenters = [];
    currentStatus.active = false; 

    try {
        fs.writeFileSync(STATUS_FILE, JSON.stringify(currentStatus, null, 2), "utf8");
        console.log(`✅ Status prezentujúceho resetovaný.`);
        return true;
    } catch (e) {
        console.error("Chyba pri zápise resetu do status.json:", e);
        return false;
    }
}


// Uisti sa, že hls priečinok existuje (nič nemažeme, status.json nechávame na pokoji)
if (!fs.existsSync(HLS_DIR)) {
  fs.mkdirSync(HLS_DIR, { recursive: true });
}

// ==============================
// /api/set-presenter – Zápis jména (volá Publisher při START)
// ==============================

app.post("/api/set-presenter", (req, res) => {
    const { username } = req.body;

    if (!username) {
        return res.status(400).json({ success: false, error: "Missing username" });
    }

    if (savePresenterStatus(username)) {
        return res.json({ success: true, message: "Jméno úspešne uložené." });
    } else {
        return res.status(500).json({ success: false, error: "Chyba pri zápise na disk." });
    }
});


// ==============================
// /api/clear-presenter – Reset jména (volá Publisher při STOP)
// ==============================

app.post("/api/clear-presenter", (req, res) => {
    if (clearPresenterStatus()) {
        return res.json({ success: true, message: "Status úspešne resetovaný." });
    } else {
        return res.status(500).json({ success: false, error: "Chyba pri resetovaní statusu na disku." });
    }
});


// ==============================
// /api/status – Čítanie status.json (volá Viewer periodicky)
// ==============================

app.get("/api/status", (req, res) => {
  try {
    if (!fs.existsSync(STATUS_FILE)) {
      return res.json({
        active: false,
        presenter: null,
        presenters: [],
      });
    }

    const json = JSON.parse(fs.readFileSync(STATUS_FILE, "utf8"));

    return res.json({
      active: json.active || false,
      presenter: json.presenter || null,
      presenters: json.presenters || (json.presenter ? [json.presenter] : []),
    });
  } catch (err) {
    console.error("STATUS ERROR:", err);
    return res.json({
      active: false,
      presenter: null,
      presenters: [],
    });
  }
});


// ==============================
// JEDNODUCHÝ FFmpeg → HLS
// ==============================

let ffmpegProcess = null;

function startHls() {
  if (ffmpegProcess) {
    try {
      ffmpegProcess.kill("SIGTERM");
    } catch {}
    ffmpegProcess = null;
  }

  console.log("🎬 Spúšťam FFmpeg → HLS (1 kvalita z udp://127.0.0.1:10000)");

  const input = "udp://127.0.0.1:10000?fifo_size=500000&overrun_nonfatal=1";

  const args = [
    "-loglevel",
    "warning",

    "-fflags",
    "+genpts+discardcorrupt",
    "-flags",
    "low_delay",
    "-probesize",
    "5000000",
    "-analyzeduration",
    "10000000",

    "-i",
    input,

    // video + voliteľné audio
    "-map",
    "0:v:0",
    "-map",
    "0:a:0?",

    "-c:v",
    "libx264",
    "-preset",
    "veryfast",
    "-tune",
    "zerolatency",

    "-c:a",
    "aac",
    "-ar",
    "48000",
    "-ac",
    "2",
    "-b:a",
    "128k",

    "-f",
    "hls",
    "-hls_time",
    "2",
    "-hls_list_size",
    "100",
    "-hls_flags",
    "delete_segments+independent_segments+program_date_time+omit_endlist",

    "-hls_segment_filename",
    path.join(HLS_DIR, "master%04d.ts"),

    path.join(HLS_DIR, "master.m3u8"),
  ];

  ffmpegProcess = spawn("ffmpeg", args);

  ffmpegProcess.stderr.on("data", (d) => {
    console.log("[FFmpeg HLS]", d.toString());
  });

  ffmpegProcess.on("close", (code, signal) => {
    console.log(`⚠️ FFmpeg HLS skončil (code=${code}, signal=${signal})`);
    ffmpegProcess = null;
    
    // Pokud FFmpeg spadne, resetujeme status jména, aby Viewer neukazoval staré jméno
    clearPresenterStatus();
  });
}

startHls();

// ==============================
// STATIC FILES
// ==============================

app.use("/hls", express.static(HLS_DIR));
app.use("/", express.static(VIEWER_DIR));

app.get("/viewer", (req, res) => {
  res.sendFile(path.join(VIEWER_DIR, "index.html"));
});

// ==============================
// START SERVER
// ==============================

app.listen(8080, () => {
  console.log(
    "🌐 HTTP server (viewer + HLS) beží na http://localhost:8080/viewer"
  );
});