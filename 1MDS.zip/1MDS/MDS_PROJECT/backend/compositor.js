// compositor.js – GRID 3×2 pre max 6 publisherov (opravená 1-input verzia)

import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import { spawn } from "child_process";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const STATUS_FILE = path.join(__dirname, "../hls/status.json");
const OUTPUT_UDP = "udp://127.0.0.1:10000";

let ffmpegProcess = null;

// Poll každé 2 sekundy
setInterval(updateCompositor, 2000);
console.log("🎛 GRID COMPOSITOR beží…");

// ---------------------------------------------------------------
// Load presenters
// ---------------------------------------------------------------
function loadPresenters() {
  try {
    if (!fs.existsSync(STATUS_FILE)) return [];
    const json = JSON.parse(fs.readFileSync(STATUS_FILE, "utf8"));
    return json.presenters || [];
  } catch {
    return [];
  }
}

// ---------------------------------------------------------------
// GRID LAYOUT PRE 2–6 INPUTOV
// ---------------------------------------------------------------
function buildGridLayout(count) {
  if (count === 2) {
    return {
      layout: "0_0|960_0",
      width: 960,
      height: 1080
    };
  }
  if (count <= 4) {
    return {
      layout: "0_0|960_0|0_540|960_540",
      width: 960,
      height: 540
    };
  }
  return {
    layout: "0_0|640_0|1280_0|0_540|640_540|1280_540",
    width: 640,
    height: 540
  };
}

// ---------------------------------------------------------------
// Stop FFmpeg
// ---------------------------------------------------------------
function stopFFmpeg() {
  if (ffmpegProcess) {
    try { ffmpegProcess.kill("SIGTERM"); } catch {}
    ffmpegProcess = null;
    console.log("🛑 Zastavený predchádzajúci GRID");
  }
}

// ---------------------------------------------------------------
// Start FFmpeg GRID OR SINGLE
// ---------------------------------------------------------------
function startGrid(presenters) {
  const count = presenters.length;
  stopFFmpeg();

  if (count === 0) return;

  // -------------------------
  // 1 INPUT → ŽIADNY XSTACK
  // -------------------------
  if (count === 1) {
    const p = presenters[0];
    const udp = `udp://127.0.0.1:${p.port}`;

    console.log("🎬 Spúšťam SINGLE režim pre 1 publishera");

    ffmpegProcess = spawn("ffmpeg", [
      "-i", udp,
      "-vf", "scale=1920:1080",
      "-c:v", "libx264",
      "-preset", "veryfast",
      "-tune", "zerolatency",
      "-f", "mpegts",
      OUTPUT_UDP
    ]);

    ffmpegProcess.stderr.on("data", d => console.log("FFMPEG SINGLE:", d.toString()));
    return;
  }

  // -------------------------
  // 2-6 INPUTOV → XSTACK
  // -------------------------
  const grid = buildGridLayout(count);
  const inputs = presenters.flatMap(p => ["-i", `udp://127.0.0.1:${p.port}`]);

  const xstackInputs = presenters.map((p, i) => `[${i}:v]`).join("");

  const xstackFilter = `${xstackInputs}xstack=inputs=${count}:layout=${grid.layout}[v]`;

  // overlay mien
  const drawTexts = presenters.map((p, idx) => {
    const col = idx % 3;
    const row = Math.floor(idx / 3);
    const x = col * grid.width + 20;
    const y = row * grid.height + 40;

    return `[v]drawtext=text='${p.name}':x=${x}:y=${y}:fontsize=24:fontcolor=white:box=1:boxcolor=0x000000AA[v]`;
  }).join(";");

  const filter = `${xstackFilter};${drawTexts}`;

  console.log(`🎬 Spúšťam GRID pre ${count} publisherov`);

  ffmpegProcess = spawn("ffmpeg", [
    ...inputs,
    "-filter_complex", filter,
    "-map", "[v]",
    "-c:v", "libx264",
    "-preset", "veryfast",
    "-tune", "zerolatency",
    "-f", "mpegts",
    OUTPUT_UDP
  ]);

  ffmpegProcess.stderr.on("data", d => console.log("FFMPEG GRID:", d.toString()));
}

// ---------------------------------------------------------------
// DETECT CHANGE AND RESTART
// ---------------------------------------------------------------
let lastPorts = "";

function updateCompositor() {
  const presenters = loadPresenters();
  const ports = presenters.map(p => p.port).join(",");

  if (ports !== lastPorts) {
    lastPorts = ports;
    startGrid(presenters);
  }
}
