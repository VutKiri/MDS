// media-ingest.js — multi-publisher verzia (max 6 publisherov)

import { WebSocketServer } from "ws";
import { spawn } from "child_process";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// status.json vedľa HLS (../hls/status.json)
const STATUS_FILE = path.join(__dirname, "../hls/status.json");

// Pevné UDP porty pre publisherov (blbuvzdorné, ľahko zmeniteľné)
const PUBLISHER_PORTS = [11001, 11002, 11003, 11004, 11005, 11006];
const MAX_PUBLISHERS = PUBLISHER_PORTS.length;

// Jeden "slot" = jedno spojenie + jeho FFmpeg ingest
const slots = Array(MAX_PUBLISHERS).fill(null);

/**
 * Zapíše status.json tak, aby bol kompatibilný
 * so starým aj novým live-server.js
 */
function updateStatusFile() {
  const activePresenters = slots
    .map((slot, index) => {
      if (!slot) return null;
      return {
        id: `slot${index + 1}`,
        name: slot.name,
        port: PUBLISHER_PORTS[index],
        active: true,
      };
    })
    .filter(Boolean);

  const payload = {
    active: activePresenters.length > 0,
    // starý formát: string s menami (kvôli kompatibilite)
    presenter:
      activePresenters.length > 0
        ? activePresenters.map((p) => p.name).join(", ")
        : null,
    // nový formát: pole
    presenters: activePresenters,
  };

  try {
    fs.mkdirSync(path.dirname(STATUS_FILE), { recursive: true });
    fs.writeFileSync(STATUS_FILE, JSON.stringify(payload, null, 2));
  } catch (err) {
    console.error("STATUS write error:", err);
  }
}

// Na začiatku: žiadni aktívni prezentujúci
updateStatusFile();

console.log("🚀 MEDIA INGEST server starting...");
const wss = new WebSocketServer({ port: 8090 });
console.log("✔ WS ingest beží na ws://localhost:8090");

/**
 * Nájde prvý voľný slot, alebo vráti -1 ak je plno
 */
function getFreeSlotIndex() {
  for (let i = 0; i < MAX_PUBLISHERS; i++) {
    if (!slots[i]) return i;
  }
  return -1;
}

/**
 * Vytvorí FFmpeg ingest pre daný slot
 * webm (z WebSocketu) → UDP (mpegts) na daný port
 */
function startFfmpegForSlot(slotIndex) {
  const slot = slots[slotIndex];
  const udpPort = PUBLISHER_PORTS[slotIndex];
  const udpTarget = `udp://127.0.0.1:${udpPort}`;

  console.log(
    `🎬 Spúšťam FFmpeg ingest pre slot ${slotIndex + 1} (${slot.name}) → ${udpTarget}`
  );

  const ffmpeg = spawn("ffmpeg", [
    "-nostdin",
    "-hide_banner",

    "-f",
    "webm",
    "-i",
    "pipe:0",

    // Normalizácia videa
    "-c:v",
    "libx264",
    "-preset",
    "veryfast",
    "-tune",
    "zerolatency",
    "-pix_fmt",
    "yuv420p",
    "-r",
    "30",
    "-g",
    "60",
    "-keyint_min",
    "60",

    // Normalizácia audia
    "-c:a",
    "aac",
    "-ar",
    "48000",
    "-ac",
    "2",
    "-b:a",
    "128k",

    // Výstup: mpegts cez UDP na konkrétny port
    "-f",
    "mpegts",
    udpTarget,
  ]);

  ffmpeg.stderr.on("data", (d) => {
    console.log(`FFMPEG[slot${slotIndex + 1}]:`, d.toString());
  });

  ffmpeg.on("exit", (code, signal) => {
    console.log(
      `⚠️ FFmpeg ingest slot${slotIndex + 1} skončil (code=${code}, signal=${signal})`
    );
  });

  slot.ffmpeg = ffmpeg;
}

/**
 * Zastaví FFmpeg pre daný slot
 */
function stopFfmpegForSlot(slotIndex) {
  const slot = slots[slotIndex];
  if (!slot || !slot.ffmpeg) return;

  try {
    slot.ffmpeg.stdin?.end?.();
  } catch {}
  try {
    slot.ffmpeg.kill("SIGTERM");
  } catch {}

  slot.ffmpeg = null;
}

/**
 * Resetne stav slotu (po odpojení)
 */
function resetSlot(slotIndex) {
  stopFfmpegForSlot(slotIndex);
  slots[slotIndex] = null;
  updateStatusFile();
}

// ===============================
// WEBSOCKET LOGIKA
// ===============================

wss.on("connection", (ws, req) => { // Přidáno req pro přístup k URL
  const slotIndex = getFreeSlotIndex();

  if (slotIndex === -1) {
    console.log("❌ Žiadny voľný slot pre nového publishera → close");
    ws.close(1013, "Server full");
    return;
  }

  // 🚨 KLÍČOVÁ OPRAVA: Extrahujeme clientId z URL
  const urlParams = new URLSearchParams(req.url.split('?')[1]);
  const clientId = urlParams.get('clientId') || `User ${slotIndex + 1}`; // Fallback, kdyby v URL nic nebylo

  const name = clientId; // Použijeme jméno z Publishera
  
  console.log(`👉 Publisher pripojený do slotu ${slotIndex + 1} (${name})`);

  // Per-slot stav
  slots[slotIndex] = {
    ws,
    name, // ✅ TADY POUŽÍVÁME KLIENTID
    ffmpeg: null,
    headerFound: false,
    keyframeFound: false,
    headerBuffer: null,
    tempChunks: [],
  };

  updateStatusFile();

  ws.binaryType = "arraybuffer";

  ws.on("message", (msg, isBinary) => {
    const slot = slots[slotIndex];
    if (!slot) return; // slot už uvoľnený?

    // Textová správa → v budúcnosti môžeme použiť na meno, ID atď.
    if (!isBinary) {
      // napr. tu by šlo spracovať JSON s menom
      return;
    }

    const buffer = Buffer.from(msg);

    // EBML header (WebM)
    const isEbmlHeader =
      buffer.length >= 4 &&
      buffer[0] === 0x1a &&
      buffer[1] === 0x45 &&
      buffer[2] === 0xdf &&
      buffer[3] === 0xa3;

    if (!slot.headerFound) {
      if (!isEbmlHeader) {
        console.log(`⚠ [slot${slotIndex + 1}] Čakám na EBML HEADER`);
        return;
      }
      slot.headerFound = true;
      slot.headerBuffer = buffer;
      console.log(`✔ [slot${slotIndex + 1}] EBML HEADER OK`);
      return;
    }

    // Detekcia KEYFRAME (VP8)
    const isKeyframe = buffer.includes(Buffer.from([0x9d, 0x01, 0x2a]));

    if (!slot.keyframeFound) {
      slot.tempChunks.push(buffer);

      if (!isKeyframe) {
        console.log(`⚠ [slot${slotIndex + 1}] Čakám na KEYFRAME…`);
        return;
      }

      console.log(`🎬 [slot${slotIndex + 1}] KEYFRAME OK → spúšťam FFmpeg ingest`);
      startFfmpegForSlot(slotIndex);

      // zapíš header + doterajšie buffery
      if (slot.ffmpeg?.stdin?.writable) {
        slot.ffmpeg.stdin.write(slot.headerBuffer);
        for (const chunk of slot.tempChunks) {
          slot.ffmpeg.stdin.write(chunk);
        }
      }

      slot.tempChunks = [];
      slot.keyframeFound = true;
      return;
    }

    // Po KEYFRAME posielame všetko rovno do ffmpeg stdin
    if (slot.ffmpeg && slot.ffmpeg.stdin.writable) {
      slot.ffmpeg.stdin.write(buffer);
    }
  });

  ws.on("close", () => {
    console.log(`❌ Publisher v slote ${slotIndex + 1} odpojený`);
    resetSlot(slotIndex);
  });

  ws.on("error", (err) => {
    console.log(`⚠️ WS error v slote ${slotIndex + 1}:`, err);
    resetSlot(slotIndex);
  });
});