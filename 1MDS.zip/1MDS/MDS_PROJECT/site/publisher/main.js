const video = document.getElementById('localVideo');
const startBtn = document.getElementById('startBtn');
const stopBtn = document.getElementById('stopBtn');
const grayscaleSwitch = document.getElementById('grayscaleSwitch');
const usernameInput = document.getElementById('jmeno_uzivatele');
const passwordInput = document.getElementById('password');
const loginBtn = document.getElementById('loginBtn');
const microphonSwitch = document.getElementById('microphonSwitch');
let authenticatedUsername = '';

let grayScaleEnabled = false;
let microphonSwitchEnable = false;

const canvasVideo = document.getElementById('modifiedVideo');
const ctxVideo = canvasVideo.getContext('2d');
const canvasOverlay = document.getElementById('overlay');

let mediaRecorder;
let localStream;
let ws;

startBtn.disabled = true; 



/* ============================================================
   SPUSTENIE STREAMOVANIA – PO ÚSPEŠNOM PRIHLÁSENÍ
============================================================ */
function startStreamingSetup(clientId) {

    ws = new WebSocket(`ws://localhost:8090?clientId=${clientId}`);
    ws.binaryType = 'arraybuffer';

    ws.onopen = () => {
        console.log("Connected to ingest server");

        // VIDEO STREAM Z CANVAS
        const videoStreamFromCanvas = canvasVideo.captureStream(30);

        const mixedStream = new MediaStream();
        videoStreamFromCanvas.getVideoTracks().forEach(t => mixedStream.addTrack(t));

        if (microphonSwitchEnable) {
            localStream.getAudioTracks().forEach(t => mixedStream.addTrack(t));
        }

        // Vynútiť keyframe hneď
        const track = mixedStream.getVideoTracks()[0];
        if (track && track.requestFrame) {
            console.log("🔵 Nútený keyframe");
            track.requestFrame();
        }

       mediaRecorder = new MediaRecorder(mixedStream, {
              mimeType: "video/webm;codecs=vp8,opus",
              videoBitsPerSecond: 2000000,
              audioBitsPerSecond: 128000,
          });

          mediaRecorder.ondataavailable = (e) => {
              if (e.data.size > 0 && ws.readyState === WebSocket.OPEN) {
                  ws.send(e.data);
              }
          };

          mediaRecorder.onstart = () => {
              console.log("Forcing KEYFRAME via requestData()");
              setTimeout(() => mediaRecorder.requestData(), 200);
          };

          mediaRecorder.start(500);


        // požiadavka na keyframe po 50ms
        setTimeout(() => {
            if (mediaRecorder && mediaRecorder.state === "recording") {
                console.log("Forcing first KEYFRAME…");
                mediaRecorder.requestData();
            }
        }, 50);

        startBtn.disabled = true;
        stopBtn.disabled = false;

        console.log("Recording started");
    };


    ws.onclose = () => {
        console.log("Disconnected.");
        stopBtn.disabled = true;
        startBtn.disabled = false;
        loginBtn.style.display = "block";
    };

    ws.onerror = (err) => {
        console.error("WS error:", err);
        stopBtn.disabled = true;
        startBtn.disabled = false;
    };
}



/* ============================================================
   LOGIN – OVERENIE UŽÍVATEĽA
============================================================ */
loginBtn.addEventListener('click', async () => {

    const username = usernameInput.value;
    const password = passwordInput.value;

    loginBtn.disabled = true;

    try {
        const authResponse = await fetch("http://localhost:3000/authenticate", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ username, password })
        });

        const result = await authResponse.json();

        if (authResponse.ok && result.authenticated) {
            console.log("Autentizace úspěšná");
            authenticatedUsername = username;

            // ✅ Odeslání jména na Live Server po úspěšné autentizaci
            const liveServerUrl = 'http://localhost:8080/api/set-presenter'; 

            // Odešle jméno, které uživatel zadal do pole usernameInput
            fetch(liveServerUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username: username }) 
            })
            
            .then(res => res.json())
            .then(data => {

                if (data.success) {
                    console.log('Jméno prezentujúceho úspešne uložené na Live Server.');
                } else {
                    console.error('Chyba pri ukladaní jména na Live Server:', data.error);
                }
            })
            .catch(err => console.error('Chyba pri komunikácii s Live Serverom:', err));

                        startBtn.disabled = false;

        } else {
            alert("Chybné heslo nebo uživatelské jméno.");
            loginBtn.disabled = false;
        }

    } catch (err) {
        alert("Chyba: Autentizační server nedostupný.");
        loginBtn.disabled = false;
    }
});



/* ============================================================
   TLAČIDLO START – SPUSTÍ STREAMING
============================================================ */
startBtn.addEventListener('click', () => {
    const clientId = authenticatedUsername;
    document.getElementById("clientIdSpan").innerText = clientId;
    startStreamingSetup(clientId);
});



/* ============================================================
   VIDEO + CANVAS PIPELINE
============================================================ */
async function init() {
    localStream = await navigator.mediaDevices.getUserMedia({
        video: true,
        audio: true
    });

    video.srcObject = localStream;

    video.onloadedmetadata = () => {
        canvasVideo.width = video.videoWidth;
        canvasVideo.height = video.videoHeight;
        canvasOverlay.width = video.videoWidth;
        canvasOverlay.height = video.videoHeight;

        processVideoCanvas();
    };
}

function processVideoCanvas() {
    ctxVideo.drawImage(video, 0, 0, canvasVideo.width, canvasVideo.height);

    if (grayScaleEnabled) {
        const frame = ctxVideo.getImageData(0, 0, canvasVideo.width, canvasVideo.height);
        const d = frame.data;
        for (let i = 0; i < d.length; i += 4) {
            const avg = (d[i] + d[i + 1] + d[i + 2]) / 3;
            d[i] = d[i + 1] = d[i + 2] = avg;
        }
        ctxVideo.putImageData(frame, 0, 0);
    }

    requestAnimationFrame(processVideoCanvas);
}



/* ============================================================
   TLAČIDLO STOP
============================================================ */
stopBtn.addEventListener('click', () => {
    if (mediaRecorder && mediaRecorder.state === "recording") {
        mediaRecorder.stop();
    }
    if (ws) ws.close();

    console.log("Recording stopped");
});



/* ============================================================
   SWITCHES
============================================================ */
grayscaleSwitch.addEventListener('change', () => {
    grayScaleEnabled = grayscaleSwitch.checked;
});

microphonSwitch.addEventListener('change', () => {
    microphonSwitchEnable = microphonSwitch.checked;
});

init();
