const videoEl = document.getElementById("player");
const statusEl = document.getElementById("streamStatus");
const qualitySelect = document.getElementById("qualitySelect");
const presenterNameEl = document.getElementById("presenterName");
const presenterCountEl = document.getElementById("presenterCount");

// FIX → musí ísť na Node server, nie na port 80
const HLS_URL = "http://localhost:8080/hls/master.m3u8";
const STATUS_URL = "http://localhost:8080/api/status";

let player = null;
let lastStreamActive = false;

/* ------------------------- INIT VIDEO.JS ------------------------- */

function initPlayer() {
  if (player) {
    try { player.dispose(); } catch {}
  }

  player = videojs("player", {
    autoplay: false,
    controls: true,
    liveui: true,
    fluid: true
  });

  player.src({
    src: HLS_URL,
    type: "application/x-mpegURL"
  });

  player.on("loadedmetadata", () => {
    console.log("Video.js: metadata loaded");

    const levels = player.qualityLevels();

    qualitySelect.innerHTML = "";
    qualitySelect.appendChild(new Option("Automaticky", "auto"));
    qualitySelect.disabled = false;

    for (let i = 0; i < levels.length; i++) {
      const lvl = levels[i];
      const label = `${lvl.height}p (${Math.round(lvl.bitrate / 1000)} kbps)`;
      qualitySelect.appendChild(new Option(label, i));
    }

    player.play().catch(err => console.warn("Autoplay blocked:", err));
  });

  player.on("error", () => {
    console.warn("Player error:", player.error());
  });
}

/* ---------------------- SELECT KVALITY ---------------------- */

qualitySelect.addEventListener("change", () => {
  if (!player) return;

  const sel = qualitySelect.value;
  const levels = player.qualityLevels();

  if (sel === "auto") {
    for (let i = 0; i < levels.length; i++) levels[i].enabled = true;
    console.log("Quality: AUTO");
    return;
  }

  const idx = Number(sel);

  for (let i = 0; i < levels.length; i++)
    levels[i].enabled = (i === idx);

  console.log("Quality: manual", idx);
});

/* --------------------------- STATUS --------------------------- */

function setStatus(text, ok = false) {
  statusEl.textContent = text;
  statusEl.classList.remove("bg-secondary", "bg-success");
  statusEl.classList.add(ok ? "bg-success" : "bg-secondary");
}

/* ------------------------- POLLING ---------------------------- */

async function pollStatus() {
  try {
    const res = await fetch(STATUS_URL, { cache: "no-cache" });
    const json = await res.json();

    const active = Boolean(json.active);
    const presenter = json.presenter || null;

    presenterNameEl.textContent = presenter || "–";
    presenterCountEl.textContent = presenter ? "1" : "0";

    if (active) {
      setStatus("Vysílání běží", true);

      if (!lastStreamActive) {
        console.log("Stream ON → init Video.js");
        initPlayer();
      }

      lastStreamActive = true;
    } else {
      setStatus("Čeká se na zahájení vysílání…", false);
      lastStreamActive = false;
    }

  } catch (err) {
    console.warn("Chyba při dotazu /api/status:", err);
  }

  setTimeout(pollStatus, 2000);
}

pollStatus();
